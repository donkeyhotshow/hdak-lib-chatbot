/**
 * KSAC Electronic Catalog Parser
 * Parses documents from KSAC library electronic catalog
 * URL: https://library-service.com.ua:8443/khkhdak/DocumentSearchForm
 *
 * Strategy:
 * 1. Start with single page parsing to test structure
 * 2. Implement incremental harvesting with rate limiting
 * 3. Handle pagination and resumption tokens
 * 4. Parse metadata and extract document links
 */

import axios, { AxiosInstance } from "axios";
import * as cheerio from "cheerio";

const CATALOG_BASE_URL = "https://library-service.com.ua:8443/khkhdak";

interface CatalogDocument {
  externalId: string;
  titleUk: string;
  titleEn?: string;
  authors: string[];
  year?: number;
  documentType?: string;
  language?: string;
  abstractUk?: string;
  keywords: string[];
  isbn?: string;
  issn?: string;
  publisher?: string;
  url: string;
  metadata: Record<string, unknown>;
}

class CatalogParser {
  private client: AxiosInstance;
  private requestDelay: number = 1000; // 1 second delay between requests

  constructor() {
    this.client = axios.create({
      baseURL: CATALOG_BASE_URL,
      timeout: 30000,
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      },
    });
  }

  /**
   * Parse a single catalog page
   */
  async parsePage(pageNumber: number = 1): Promise<CatalogDocument[]> {
    try {
      console.log(`[CatalogParser] Parsing page ${pageNumber}...`);

      // Construct search URL with pagination
      const searchUrl = `/DocumentSearchForm?page=${pageNumber}&pageSize=20&sort=relevance`;

      const response = await this.client.get(searchUrl);
      const $ = cheerio.load(response.data);

      const documents: CatalogDocument[] = [];

      // Parse search results - adjust selectors based on actual HTML structure
      $(".search-result, .document-item, [data-document-id]").each(
        (index: number, element: any) => {
          try {
            const $elem = $(element);

            // Extract title
            const titleElem = $elem.find(".title, h3, .document-title");
            const titleUk = titleElem.text().trim();

            if (!titleUk) {
              console.warn(`[CatalogParser] Skipping result ${index}: no title found`);
              return;
            }

            // Extract authors
            const authorsElem = $elem.find(".author, .creators, [data-authors]");
            const authorsText = authorsElem.text().trim();
            const authors = authorsText
              .split(";")
              .map((a: string) => a.trim())
              .filter((a: string) => a.length > 0);

            // Extract year
            const yearElem = $elem.find(".year, .date, [data-year]");
            const yearText = yearElem.text().trim();
            const year = yearText ? parseInt(yearText) : undefined;

            // Extract document type
            const typeElem = $elem.find(".type, .document-type, [data-type]");
            const documentType = typeElem.text().trim() || "unknown";

            // Extract ISBN/ISSN
            const isbnElem = $elem.find(".isbn, [data-isbn]");
            const isbn = isbnElem.text().trim();

            const issnElem = $elem.find(".issn, [data-issn]");
            const issn = issnElem.text().trim();

            // Extract abstract
            const abstractElem = $elem.find(".abstract, .description, [data-abstract]");
            const abstractUk = abstractElem.text().trim();

            // Extract keywords
            const keywordsElem = $elem.find(".keywords, .tags, [data-keywords]");
            const keywordsText = keywordsElem.text().trim();
            const keywords = keywordsText
              .split(",")
              .map((k: string) => k.trim())
              .filter((k: string) => k.length > 0);

            // Extract document link
            const linkElem = $elem.find("a[href*='document'], a[href*='item']");
            const relativeUrl = linkElem.attr("href");
            const url = relativeUrl
              ? `${CATALOG_BASE_URL}${relativeUrl}`
              : `${CATALOG_BASE_URL}/document/${index}`;

            // Extract external ID from URL or data attribute
            const externalIdElem = $elem.attr("data-document-id");
            const externalId = externalIdElem || `catalog-${pageNumber}-${index}`;

            const doc: CatalogDocument = {
              externalId,
              titleUk,
              authors,
              year,
              documentType,
              language: "uk",
              abstractUk,
              keywords,
              isbn: isbn || undefined,
              issn: issn || undefined,
              url,
              metadata: {
                pageNumber,
                position: index,
                parseDate: new Date().toISOString(),
              },
            };

            documents.push(doc);
          } catch (error) {
            console.error(`[CatalogParser] Error parsing result ${index}:`, error);
          }
        }
      );

      console.log(`[CatalogParser] Parsed ${documents.length} documents from page ${pageNumber}`);
      return documents;
    } catch (error) {
      console.error(`[CatalogParser] Error parsing page ${pageNumber}:`, error);
      throw error;
    }
  }

  /**
   * Parse multiple pages with rate limiting
   */
  async parsePages(
    startPage: number = 1,
    endPage: number = 5,
    delayMs: number = 1000
  ): Promise<CatalogDocument[]> {
    const allDocuments: CatalogDocument[] = [];

    for (let page = startPage; page <= endPage; page++) {
      try {
        const docs = await this.parsePage(page);
        allDocuments.push(...docs);

        // Rate limiting - wait before next request
        if (page < endPage) {
          console.log(
            `[CatalogParser] Waiting ${delayMs}ms before next page...`
          );
          await new Promise((resolve) => setTimeout(resolve, delayMs));
        }
      } catch (error) {
        console.error(`[CatalogParser] Error on page ${page}, continuing...`);
        // Continue with next page on error
      }
    }

    return allDocuments;
  }

  /**
   * Search catalog for documents
   */
  async search(
    query: string,
    pageSize: number = 20
  ): Promise<CatalogDocument[]> {
    try {
      console.log(`[CatalogParser] Searching for: "${query}"`);

      // Construct search URL
      const searchUrl = `/DocumentSearchForm?query=${encodeURIComponent(query)}&pageSize=${pageSize}`;

      const response = await this.client.get(searchUrl);
      const $ = cheerio.load(response.data);

      const documents: CatalogDocument[] = [];

      // Parse search results
      $(".search-result, .document-item, [data-document-id]").each(
        (index: number, element: any) => {
          try {
            const $elem = $(element);

            const titleElem = $elem.find(".title, h3, .document-title");
            const titleUk = titleElem.text().trim();

            if (!titleUk) return;

            const authorsElem = $elem.find(".author, .creators");
            const authors = authorsElem
              .text()
              .split(";")
              .map((a: string) => a.trim())
              .filter((a: string) => a.length > 0);

            const yearElem = $elem.find(".year, .date");
            const year = yearElem.text().trim()
              ? parseInt(yearElem.text().trim())
              : undefined;

            const linkElem = $elem.find("a[href*='document']");
            const relativeUrl = linkElem.attr("href");
            const url = relativeUrl
              ? `${CATALOG_BASE_URL}${relativeUrl}`
              : `${CATALOG_BASE_URL}/document/${index}`;

            const externalId = $elem.attr("data-document-id") || `search-${index}`;

            documents.push({
              externalId,
              titleUk,
              authors,
              year,
              documentType: "unknown",
              language: "uk",
              keywords: [],
              url,
              metadata: {
                searchQuery: query,
                searchDate: new Date().toISOString(),
              },
            });
          } catch (error) {
            console.error(`[CatalogParser] Error parsing search result ${index}:`, error);
          }
        }
      );

      console.log(`[CatalogParser] Found ${documents.length} results for "${query}"`);
      return documents;
    } catch (error) {
      console.error(`[CatalogParser] Search error:`, error);
      throw error;
    }
  }

  /**
   * Get total number of documents in catalog
   */
  async getTotalDocumentCount(): Promise<number> {
    try {
      console.log("[CatalogParser] Fetching total document count...");

      const response = await this.client.get("/DocumentSearchForm");
      const $ = cheerio.load(response.data);

      // Look for total count indicator
      const countElem = $(
        ".total-results, [data-total-count], .result-count"
      );
      const countText = countElem.text().trim();

      // Try to extract number from text like "Total: 303,552 documents"
      const match = countText.match(/(\d+[,.]?\d*)/);
      if (match) {
        const count = parseInt(match[1].replace(/[,.]/, ""));
        console.log(`[CatalogParser] Total documents: ${count}`);
        return count;
      }

      console.warn("[CatalogParser] Could not determine total document count");
      return 0;
    } catch (error) {
      console.error("[CatalogParser] Error fetching total count:", error);
      return 0;
    }
  }

  /**
   * Set request delay for rate limiting
   */
  setRequestDelay(delayMs: number): void {
    this.requestDelay = delayMs;
    console.log(`[CatalogParser] Request delay set to ${delayMs}ms`);
  }
}

export const catalogParser = new CatalogParser();
export type { CatalogDocument };
