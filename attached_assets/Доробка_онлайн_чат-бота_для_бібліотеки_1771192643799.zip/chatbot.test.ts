import * as db from "./db";

describe("Chatbot Database Functions", () => {
  describe("Library Resource Management", () => {
    it("should retrieve all resources from database", async () => {
      const resources = await db.getAllResources();
      
      expect(Array.isArray(resources)).toBe(true);
      expect(resources.length).toBeGreaterThan(0);
      
      // Verify seeded resources exist
      const hasElectronicLibrary = resources.some(r => r.nameEn === "Electronic Library");
      expect(hasElectronicLibrary).toBe(true);
    });

    it("should search resources by English keywords", async () => {
      const resources = await db.searchResources("library");
      
      expect(Array.isArray(resources)).toBe(true);
      expect(resources.length).toBeGreaterThan(0);
    });

    it("should search resources by Ukrainian keywords", async () => {
      const resources = await db.searchResources("бібліотека");
      
      expect(Array.isArray(resources)).toBe(true);
    });

    it("should search resources by Russian keywords", async () => {
      const resources = await db.searchResources("база");
      
      expect(Array.isArray(resources)).toBe(true);
    });

    it("should filter resources by type database", async () => {
      const resources = await db.getResourcesByType("database");
      
      expect(Array.isArray(resources)).toBe(true);
      expect(resources.length).toBeGreaterThan(0);
      
      // Verify all returned resources are of type database
      resources.forEach(r => {
        expect(r.type).toBe("database");
      });
    });

    it("should filter resources by type electronic_library", async () => {
      const resources = await db.getResourcesByType("electronic_library");
      
      expect(Array.isArray(resources)).toBe(true);
      expect(resources.length).toBeGreaterThan(0);
    });

    it("should create a new resource", async () => {
      const timestamp = Date.now();
      const resource = await db.createResource({
        nameEn: `Test Resource ${timestamp}`,
        nameUk: `Тестовий ресурс ${timestamp}`,
        nameRu: `Тестовый ресурс ${timestamp}`,
        type: "other",
        url: "https://test.example.com",
      });
      
      expect(resource).toBeDefined();
      expect(resource?.url).toBe("https://test.example.com");
    });

    it("should update a resource", async () => {
      const timestamp = Date.now();
      const created = await db.createResource({
        nameEn: `Original ${timestamp}`,
        type: "other",
      });

      if (created) {
        const updated = await db.updateResource(created.id, {
          nameEn: `Updated ${timestamp}`,
        });
        