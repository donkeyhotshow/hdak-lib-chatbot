/**
 * Database helpers for document management
 * Handles storage and retrieval of documents from DSpace, catalog, and other sources
 */

import { eq, and, like, desc } from "drizzle-orm";
import { getDb } from "./db";
import {
  documents,
  InsertDocument,
  Document,
  dspaceSyncStatus,
  InsertDspaceSyncStatus,
  DspaceSyncStatus,
  catalogSyncStatus,
  InsertCatalogSyncStatus,
  CatalogSyncStatus,
} from "../drizzle/schema";

/**
 * Create or update a document
 */
export async function upsertDocument(doc: InsertDocument): Promise<Document | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert document: database not available");
    return null;
  }

  try {
    // Check if document already exists
    const existing = await db
      .select()
      .from(documents)
      .where(
        and(
          eq(documents.source, doc.source!),
          eq(documents.externalId, doc.externalId!)
        )
      )
      .limit(1);

    if (existing.length > 0) {
      // Update existing document
      await db
        .update(documents)
        .set({
          ...doc,
          updatedAt: new Date(),
        })
        .where(eq(documents.id, existing[0].id));

      return existing[0];
    } else {
      // Insert new document
      const result = await db.insert(documents).values(doc);
      const insertedId = (result as any).insertId;

      if (insertedId) {
        const inserted = await db
          .select()
          .from(documents)
          .where(eq(documents.id, insertedId))
          .limit(1);
        return inserted[0] || null;
      }
      return null;
    }
  } catch (error) {
    console.error("[Database] Failed to upsert document:", error);
    throw error;
  }
}

/**
 * Search documents by keyword
 */
export async function searchDocuments(
  query: string,
  language: "en" | "uk" | "ru" = "uk",
  limit: number = 20
): Promise<Document[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot search documents: database not available");
    return [];
  }

  try {
    const searchPattern = `%${query}%`;

    const titleField =
      language === "en"
        ? documents.titleEn
        : language === "ru"
          ? documents.titleRu
          : documents.titleUk;

    const results = await db
      .select()
      .from(documents)
      .where(like(titleField, searchPattern))
      .limit(limit);

    return results;
  } catch (error) {
    console.error("[Database] Failed to search documents:", error);
    return [];
  }
}

/**
 * Get documents by source
 */
export async function getDocumentsBySource(
  source: "dspace" | "catalog" | "electronic_library",
  limit: number = 50,
  offset: number = 0
): Promise<Document[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get documents: database not available");
    return [];
  }

  try {
    const results = await db
      .select()
      .from(documents)
      .where(eq(documents.source, source))
      .limit(limit)
      .offset(offset);

    return results;
  } catch (error) {
    console.error("[Database] Failed to get documents by source:", error);
    return [];
  }
}

/**
 * Get documents by type
 */
export async function getDocumentsByType(
  documentType: string,
  limit: number = 50
): Promise<Document[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get documents: database not available");
    return [];
  }

  try {
    const results = await db
      .select()
      .from(documents)
      .where(eq(documents.documentType, documentType))
      .limit(limit);

    return results;
  } catch (error) {
    console.error("[Database] Failed to get documents by type:", error);
    return [];
  }
}

/**
 * Get documents by year
 */
export async function getDocumentsByYear(
  year: number,
  limit: number = 50
): Promise<Document[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get documents: database not available");
    return [];
  }

  try {
    const results = await db
      .select()
      .from(documents)
      .where(eq(documents.year, year))
      .orderBy(desc(documents.createdAt))
      .limit(limit);

    return results;
  } catch (error) {
    console.error("[Database] Failed to get documents by year:", error);
    return [];
  }
}

/**
 * Get recent documents
 */
export async function getRecentDocuments(limit: number = 20): Promise<Document[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get documents: database not available");
    return [];
  }

  try {
    const results = await db
      .select()
      .from(documents)
      .orderBy(desc(documents.createdAt))
      .limit(limit);

    return results;
  } catch (error) {
    console.error("[Database] Failed to get recent documents:", error);
    return [];
  }
}

/**
 * Count documents by source
 */
export async function countDocumentsBySource(
  source: "dspace" | "catalog" | "electronic_library"
): Promise<number> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot count documents: database not available");
    return 0;
  }

  try {
    const result = await db
      .select()
      .from(documents)
      .where(eq(documents.source, source));

    return result.length;
  } catch (error) {
    console.error("[Database] Failed to count documents:", error);
    return 0;
  }
}

/**
 * Get DSpace sync status
 */
export async function getDspaceSyncStatus(): Promise<DspaceSyncStatus | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get sync status: database not available");
    return null;
  }

  try {
    const result = await db.select().from(dspaceSyncStatus).limit(1);
    return result[0] || null;
  } catch (error) {
    console.error("[Database] Failed to get DSpace sync status:", error);
    return null;
  }
}

/**
 * Update DSpace sync status
 */
export async function updateDspaceSyncStatus(
  status: Partial<InsertDspaceSyncStatus>
): Promise<DspaceSyncStatus | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update sync status: database not available");
    return null;
  }

  try {
    const existing = await getDspaceSyncStatus();

    if (existing) {
      await db
        .update(dspaceSyncStatus)
        .set({
          ...status,
          updatedAt: new Date(),
        })
        .where(eq(dspaceSyncStatus.id, existing.id));

      const updated = await db
        .select()
        .from(dspaceSyncStatus)
        .where(eq(dspaceSyncStatus.id, existing.id))
        .limit(1);

      return updated[0] || null;
    } else {
      const result = await db.insert(dspaceSyncStatus).values({
        ...status,
        createdAt: new Date(),
        updatedAt: new Date(),
      } as InsertDspaceSyncStatus);

      const insertedId = (result as any).insertId;
      if (insertedId) {
        const inserted = await db
          .select()
          .from(dspaceSyncStatus)
          .where(eq(dspaceSyncStatus.id, insertedId))
          .limit(1);
        return inserted[0] || null;
      }
      return null;
    }
  } catch (error) {
    console.error("[Database] Failed to update DSpace sync status:", error);
    throw error;
  }
}

/**
 * Get Catalog sync status
 */
export async function getCatalogSyncStatus(): Promise<CatalogSyncStatus | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get sync status: database not available");
    return null;
  }

  try {
    const result = await db.select().from(catalogSyncStatus).limit(1);
    return result[0] || null;
  } catch (error) {
    console.error("[Database] Failed to get Catalog sync status:", error);
    return null;
  }
}

/**
 * Update Catalog sync status
 */
export async function updateCatalogSyncStatus(
  status: Partial<InsertCatalogSyncStatus>
): Promise<CatalogSyncStatus | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update sync status: database not available");
    return null;
  }

  try {
    const existing = await getCatalogSyncStatus();

    if (existing) {
      await db
        .update(catalogSyncStatus)
        .set({
          ...status,
          updatedAt: new Date(),
        })
        .where(eq(catalogSyncStatus.id, existing.id));

      const updated = await db
        .select()
        .from(catalogSyncStatus)
        .where(eq(catalogSyncStatus.id, existing.id))
        .limit(1);

      return updated[0] || null;
    } else {
      const result = await db.insert(catalogSyncStatus).values({
        ...status,
        createdAt: new Date(),
        updatedAt: new Date(),
      } as InsertCatalogSyncStatus);

      const insertedId = (result as any).insertId;
      if (insertedId) {
        const inserted = await db
          .select()
          .from(catalogSyncStatus)
          .where(eq(catalogSyncStatus.id, insertedId))
          .limit(1);
        return inserted[0] || null;
      }
      return null;
    }
  } catch (error) {
    console.error("[Database] Failed to update Catalog sync status:", error);
    throw error;
  }
}
