  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(libraryResources);
}

export async function searchResources(query: string): Promise<LibraryResource[]> {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(libraryResources).where(
    or(
      like(libraryResources.nameEn, `%${query}%`),
      like(libraryResources.nameUk, `%${query}%`),
      like(libraryResources.nameRu, `%${query}%`),
      like(libraryResources.descriptionEn, `%${query}%`),
      like(libraryResources.descriptionUk, `%${query}%`),
      like(libraryResources.descriptionRu, `%${query}%`)
    )
  );
}

export async function getResourcesByType(type: string): Promise<LibraryResource[]> {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(libraryResources).where(eq(libraryResources.type, type as any));
}

export async function createResource(resource: InsertLibraryResource): Promise<LibraryResource | null> {
  const db = await getDb();
  if (!db) return null;
  
  try {
    const result = await db.insert(libraryResources).values(resource);
    
    // Get the last inserted ID
    const lastId = (result as any).insertId;
    if (lastId) {
      const created = await db.select().from(libraryResources).where(eq(libraryResources.id, lastId)).limit(1);
      return created[0] || null;
    }
    
    return null;
  } catch (error) {
    console.error("Error creating resource:", error);
    return null;
  }
}

export async function updateResource(id: number, resource: Partial<InsertLibraryResource>): Promise<LibraryResource | null> {
  const db = await getDb();
  if (!db) return null;
  
  try {