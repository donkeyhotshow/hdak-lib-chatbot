/**
 * DSpace REST API Client
 * Integrates with KSAC institutional repository at https://repository.ac.kharkov.ua/
 */

import axios, { AxiosInstance } from "axios";

const DSPACE_BASE_URL = "https://repository.ac.kharkov.ua/api";

interface DSpaceAuthor {
  name: string;
  email?: string;
}

interface DSpaceMetadata {
  key: string;
  value: string;
  language?: string;
}

interface DSpaceItem {
  uuid: string;
  name: string;
  metadata: DSpaceMetadata[];
  bitstreams?: {
    uuid: string;
    name: string;
    mimeType: string;
    sizeBytes: number;
    href: string;
  }[];
}

interface DSpaceSearchResponse {
  payload: {
    currentPage: number;
    pageSize: number;
    totalPages: number;
    totalElements: number;
    _embedded?: {
      searchResultObjects?: Array<{
        _embedded?: {
          indexableObject?: DSpaceItem;
        };
      }>;
    };
  };
}

export interface ParsedDocument {
  externalId: string;
  titleUk: string;
  titleEn?: string;
  titleRu?: string;
  authors: DSpaceAuthor[];
  year?: number;
  documentType: string;
  language?: string;
  abstractUk?: string;
  abstractEn?: string;
  abstractRu?: string;
  keywords: string[];
  isbn?: string;
  issn?: string;
  publisher?: string;
  url: string;
  pdfUrl?: string;
  metadata: Record<string, unknown>;
}

class DSpaceClient {
  private client: AxiosInstance;

  constructor() {
    this.client = axios.create({
      baseURL: DSPACE_BASE_URL,
      headers: {
        Accept: "application/json",
      },
      timeout: 30000,
    });
  }

  /**
   * Search for documents in DSpace repository
   */
  async search(
    query: string,
    page: number = 0,
    pageSize: number = 20
  ): Promise<DSpaceSearchResponse> {
    try {
      const response = await this.client.get<DSpaceSearchResponse>(
        "/discover/search/objects",
        {
          params: {
            query: encodeURIComponent(query),
            dsoType: "item",
            page,
            size: pageSize,
            configuration: "default",
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error("[DSpace] Search error:", error);
      throw error;
    }
  }

  /**
   * Get a specific item by UUID
   */
  async getItem(uuid: string): Promise<DSpaceItem> {
    try {
      const response = await this.client.get<DSpaceItem>(`/core/items/${uuid}`);
      return response.data;
    } catch (error) {
      console.error(`[DSpace] Failed to get item ${uuid}:`, error);
      throw error;
    }
  }

  /**
   * Get metadata value by key
   */
  private getMetadataValue(
    metadata: DSpaceMetadata[],
    key: string,
    language?: string
  ): string | undefined {
    const match = metadata.find((m) => {
      if (language) {
        return m.key === key && m.language === language;
      }
      return m.key === key;
    });
    return match?.value;
  }

  /**
   * Get all metadata values for a key
   */
  private getMetadataValues(
    metadata: DSpaceMetadata[],
    key: string
  ): string[] {
    return metadata.filter((m) => m.key === key).map((m) => m.value);
  }

  /**
   * Parse DSpace item to internal document format
   */
  parseDocument(item: DSpaceItem): ParsedDocument {
    const metadata = item.metadata || [];

    // Extract title (prefer Ukrainian, fallback to English)
    const titleUk =
      this.getMetadataValue(metadata, "dc.title", "uk") ||
      this.getMetadataValue(metadata, "dc.title") ||
      item.name ||
      "Unknown";

    const titleEn = this.getMetadataValue(metadata, "dc.title", "en");
    const titleRu = this.getMetadataValue(metadata, "dc.title", "ru");

    // Extract authors
    const authorNames = this.getMetadataValues(metadata, "dc.creator");
    const authors: DSpaceAuthor[] = authorNames.map((name) => ({
      name,
    }));

    // Extract year
    const dateIssued = this.getMetadataValue(metadata, "dc.issued");
    const year = dateIssued ? parseInt(dateIssued.split("-")[0]) : undefined;

    // Extract language
    const language = this.getMetadataValue(metadata, "dc.language.iso");

    // Extract abstracts
    const abstractUk = this.getMetadataValue(
      metadata,
      "dc.description.abstract",
      "uk"
    );
    const abstractEn = this.getMetadataValue(
      metadata,
      "dc.description.abstract",
      "en"
    );
    const abstractRu = this.getMetadataValue(
      metadata,
      "dc.description.abstract",
      "ru"
    );

    // Extract keywords
    const keywords = this.getMetadataValues(metadata, "dc.subject");

    // Extract identifiers
    const isbn = this.getMetadataValue(metadata, "dc.identifier.isbn");
    const issn = this.getMetadataValue(metadata, "dc.identifier.issn");

    // Extract publisher
    const publisher = this.getMetadataValue(metadata, "dc.publisher");

    // Extract document type
    const documentType =
      this.getMetadataValue(metadata, "dc.type") || "document";

    // Find PDF URL
    let pdfUrl: string | undefined;
    if (item.bitstreams && item.bitstreams.length > 0) {
      const pdfBitstream = item.bitstreams.find((b) =>
        b.mimeType.includes("pdf")
      );
      if (pdfBitstream) {
        pdfUrl = pdfBitstream.href;
      }
    }

    // Build URL to item in repository
    const url = `https://repository.ac.kharkov.ua/items/${item.uuid}`;

    return {
      externalId: item.uuid,
      titleUk,
      titleEn,
      titleRu,
      authors,
      year,
      documentType,
      language,
      abstractUk,
      abstractEn,
      abstractRu,
      keywords,
      isbn,
      issn,
      publisher,
      url,
      pdfUrl,
      metadata: {
        dspaceMetadata: metadata,
        bitstreams: item.bitstreams,
      },
    };
  }

  /**
   * Harvest all documents with pagination
   */
  async harvestAll(
    pageSize: number = 100,
    maxPages?: number
  ): Promise<ParsedDocument[]> {
    const documents: ParsedDocument[] = [];
    let page = 0;
    let hasMore = true;

    while (hasMore) {
      if (maxPages && page >= maxPages) {
        break;
      }

      try {
        console.log(`[DSpace] Harvesting page ${page}...`);
        const response = await this.search("*", page, pageSize);

        if (
          !response.payload._embedded?.searchResultObjects ||
          response.payload._embedded.searchResultObjects.length === 0
        ) {
          hasMore = false;
          break;
        }

        for (const result of response.payload._embedded.searchResultObjects) {
          if (result._embedded?.indexableObject) {
            try {
              const parsed = this.parseDocument(
                result._embedded.indexableObject
              );
              documents.push(parsed);
            } catch (error) {
              console.error(
                `[DSpace] Failed to parse document:`,
                error
              );
            }
          }
        }

        page++;

        // Check if there are more pages
        if (page >= response.payload.totalPages) {
          hasMore = false;
        }
      } catch (error) {
        console.error(`[DSpace] Error harvesting page ${page}:`, error);
        hasMore = false;
      }
    }

    return documents;
  }
}

export const dspaceClient = new DSpaceClient();
