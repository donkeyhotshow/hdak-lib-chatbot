/**
 * KSAC Library FAQ and Information
 * Comprehensive knowledge base for library assistant
 */

export interface FAQItem {
  id: string;
  questionUk: string;
  questionRu: string;
  questionEn: string;
  answerUk: string;
  answerRu: string;
  answerEn: string;
  category: string;
  keywords: string[];
}

export const libraryFAQ: FAQItem[] = [
  {
    id: "hours",
    questionUk: "Які години роботи бібліотеки?",
    questionRu: "Какие часы работы библиотеки?",
    questionEn: "What are the library working hours?",
    answerUk:
      "Бібліотека ХДАК працює:\n• Понеділок-П'ятниця: 08:00-18:00\n• Субота: 10:00-16:00\n• Неділя: Закрито\n\nПід час канікул режим роботи може змінюватися. Уточніть актуальну інформацію за телефоном: +380-57-XXX-XXXX",
    answerRu:
      "Библиотека ХДАК работает:\n• Понедельник-Пятница: 08:00-18:00\n• Суббота: 10:00-16:00\n• Воскресенье: Закрыто\n\nВ период каникул режим работы может изменяться. Уточните актуальную информацию по телефону: +380-57-XXX-XXXX",
    answerEn:
      "KSAC Library hours:\n• Monday-Friday: 08:00-18:00\n• Saturday: 10:00-16:00\n• Sunday: Closed\n\nHours may change during holidays. Please call for current information: +380-57-XXX-XXXX",
    category: "general",
    keywords: ["години", "час", "роботи", "hours", "working"],
  },
  {
    id: "address",
    questionUk: "Де знаходиться бібліотека?",
    questionRu: "Где находится библиотека?",
    questionEn: "Where is the library located?",
    answerUk:
      "Адреса бібліотеки ХДАК:\nвул. Сумська, 77\nХарків, 61003\nУкраїна\n\nТелефон: +380-57-XXX-XXXX\nEmail: library@hdak.edu.ua",
    answerRu:
      "Адрес библиотеки ХДАК:\nул. Сумская, 77\nХарьков, 61003\nУкраина\n\nТелефон: +380-57-XXX-XXXX\nEmail: library@hdak.edu.ua",
    answerEn:
      "KSAC Library address:\nSumska St., 77\nKharkiv, 61003\nUkraine\n\nPhone: +380-57-XXX-XXXX\nEmail: library@hdak.edu.ua",
    category: "general",
    keywords: ["адреса", "де", "місце", "address", "location"],
  },
  {
    id: "registration",
    questionUk: "Як зареєструватися в бібліотеці?",
    questionRu: "Как зарегистрироваться в библиотеке?",
    questionEn: "How do I register at the library?",
    answerUk:
      "Для реєстрації в бібліотеці потрібно:\n1. Прийти до бібліотеки з паспортом або студентським квитком\n2. Заповнити форму реєстрації\n3. Отримати читацький квиток\n\nРеєстрація безплатна для студентів та викладачів ХДАК. Для зовнішніх користувачів може бути передбачена плата.",
    answerRu:
      "Для регистрации в библиотеке необходимо:\n1. Прийти в библиотеку с паспортом или студенческим билетом\n2. Заполнить форму регистрации\n3. Получить читательский билет\n\nРегистрация бесплатна для студентов и преподавателей ХДАК. Для внешних пользователей может предусмотрена плата.",
    answerEn:
      "To register at the library:\n1. Come to the library with a passport or student ID\n2. Fill out the registration form\n3. Get your library card\n\nRegistration is free for KSAC students and faculty. External users may need to pay a fee.",
    category: "general",
    keywords: ["реєстрація", "квиток", "читач", "registration", "card"],
  },
  {
    id: "dspace",
    questionUk: "Що таке DSpace репозитарій?",
    questionRu: "Что такое репозиторий DSpace?",
    questionEn: "What is the DSpace repository?",
    answerUk:
      "DSpace — це інституційний репозитарій ХДАК, де зберігаються:\n• Навчальні посібники\n• Монографії\n• Дисертації\n• Наукові статті\n\nВсього в репозитарії ~3,277 документів. Доступ вільний для всіх користувачів.\n\nПосилання: https://repository.ac.kharkov.ua/",
    answerRu:
      "DSpace — это институциональный репозиторий ХДАК, где хранятся:\n• Учебные пособия\n• Монографии\n• Диссертации\n• Научные статьи\n\nВсего в репозитории ~3,277 документов. Доступ свободный для всех пользователей.\n\nСсылка: https://repository.ac.kharkov.ua/",
    answerEn:
      "DSpace is KSAC's institutional repository containing:\n• Textbooks\n• Monographs\n• Dissertations\n• Research articles\n\nTotal of ~3,277 documents. Free access for all users.\n\nLink: https://repository.ac.kharkov.ua/",
    category: "resources",
    keywords: ["DSpace", "репозитарій", "документи", "repository"],
  },
  {
    id: "catalog",
    questionUk: "Як користуватися електронним каталогом?",
    questionRu: "Как пользоваться электронным каталогом?",
    questionEn: "How do I use the electronic catalog?",
    answerUk:
      "Електронний каталог ХДАК містить ~303,552 записи про:\n• Книги\n• Журнали\n• Дисертації\n• Аудіовізуальні матеріали\n\nДля пошуку:\n1. Перейдіть на https://library-service.com.ua:8443/khkhdak/\n2. Введіть ключові слова або назву документа\n3. Виберіть фільтри (рік, мова, тип)\n4. Натисніть 'Пошук'\n\nДля перегляду повного тексту потрібна авторизація.",
    answerRu:
      "Электронный каталог ХДАК содержит ~303,552 записи о:\n• Книгах\n• Журналах\n• Диссертациях\n• Аудиовизуальных материалах\n\nДля поиска:\n1. Перейдите на https://library-service.com.ua:8443/khkhdak/\n2. Введите ключевые слова или название документа\n3. Выберите фильтры (год, язык, тип)\n4. Нажмите 'Поиск'\n\nДля просмотра полного текста требуется авторизация.",
    answerEn:
      "KSAC electronic catalog contains ~303,552 records of:\n• Books\n• Journals\n• Dissertations\n• Audiovisual materials\n\nTo search:\n1. Go to https://library-service.com.ua:8443/khkhdak/\n2. Enter keywords or document title\n3. Select filters (year, language, type)\n4. Click 'Search'\n\nFull text access requires authorization.",
    category: "resources",
    keywords: ["каталог", "пошук", "документи", "catalog", "search"],
  },
  {
    id: "databases",
    questionUk: "Які міжнародні наукові бази доступні?",
    questionRu: "Какие международные научные базы доступны?",
    questionEn: "What international scientific databases are available?",
    answerUk:
      "ХДАК має корпоративний доступ до:\n• Web of Science\n• Scopus\n• ScienceDirect\n\nДля доступу потрібна авторизація через корпоративну мережу ХДАК.\n\nТакож доступний вільний пошук через Google Scholar: https://scholar.google.com/",
    answerRu:
      "ХДАК имеет корпоративный доступ к:\n• Web of Science\n• Scopus\n• ScienceDirect\n\nДля доступа требуется авторизация через корпоративную сеть ХДАК.\n\nТакже доступен свободный поиск через Google Scholar: https://scholar.google.com/",
    answerEn:
      "KSAC has corporate access to:\n• Web of Science\n• Scopus\n• ScienceDirect\n\nAccess requires authentication through KSAC corporate network.\n\nFree search is also available through Google Scholar: https://scholar.google.com/",
    category: "resources",
    keywords: ["бази", "Scopus", "Web of Science", "databases"],
  },
  {
    id: "not-found",
    questionUk: "Як зробити запит на документ, якого немає в бібліотеці?",
    questionRu: "Как сделать запрос на документ, которого нет в библиотеке?",
    questionEn: "How do I request a document not available in the library?",
    answerUk:
      "Якщо ви не знайшли потрібний документ:\n\n1. **Заповніть форму запиту** (посилання надасть асистент)\n2. **Напишіть на email**: library@hdak.edu.ua\n3. **Зателефонуйте**: +380-57-XXX-XXXX\n4. **Приходьте особисто** до бібліотеки\n\nБібліотекар розглянути ваш запит та спробує придбати або знайти документ.",
    answerRu:
      "Если вы не нашли нужный документ:\n\n1. **Заполните форму запроса** (ссылку предоставит ассистент)\n2. **Напишите на email**: library@hdak.edu.ua\n3. **Позвоните**: +380-57-XXX-XXXX\n4. **Приходите лично** в библиотеку\n\nБиблиотекарь рассмотрит ваш запрос и попытается приобрести или найти документ.",
    answerEn:
      "If you cannot find the document you need:\n\n1. **Fill out the request form** (link will be provided by assistant)\n2. **Email**: library@hdak.edu.ua\n3. **Call**: +380-57-XXX-XXXX\n4. **Visit in person** at the library\n\nA librarian will review your request and try to acquire or locate the document.",
    category: "help",
    keywords: ["запит", "немає", "пошук", "request", "not found"],
  },
  {
    id: "borrowing",
    questionUk: "Як позичити книгу?",
    questionRu: "Как взять книгу?",
    questionEn: "How do I borrow a book?",
    answerUk:
      "Для позичення книги:\n1. Знайдіть книгу в каталозі або на полиці\n2. Принесіть книгу до стійки видачі\n3. Покажіть читацький квиток\n4. Бібліотекар видасть книгу на визначений період\n\nСтандартний період позичення: 14 днів\nМожна продовжити позичення по телефону або особисто.",
    answerRu:
      "Для заимствования книги:\n1. Найдите книгу в каталоге или на полке\n2. Принесите книгу на выдачу\n3. Покажите читательский билет\n4. Библиотекарь выдаст книгу на определенный период\n\nСтандартный период заимствования: 14 дней\nМожно продлить заимствование по телефону или лично.",
    answerEn:
      "To borrow a book:\n1. Find the book in the catalog or on the shelf\n2. Bring it to the checkout desk\n3. Show your library card\n4. The librarian will issue the book for a set period\n\nStandard borrowing period: 14 days\nYou can extend the loan by phone or in person.",
    category: "services",
    keywords: ["позичити", "книга", "видача", "borrow", "loan"],
  },
  {
    id: "printing",
    questionUk: "Чи можна роздруковувати документи?",
    questionRu: "Можно ли печатать документы?",
    questionEn: "Can I print documents?",
    answerUk:
      "Так, в бібліотеці доступні послуги друку та копіювання:\n• Чорно-біле друку: 0.50 грн/сторінка\n• Кольорове друку: 2.00 грн/сторінка\n• Копіювання: 0.50 грн/копія\n\nОбратіться до бібліотекаря на стійці видачі для отримання послуги.",
    answerRu:
      "Да, в библиотеке доступны услуги печати и копирования:\n• Черно-белая печать: 0.50 грн/страница\n• Цветная печать: 2.00 грн/страница\n• Копирование: 0.50 грн/копия\n\nОбратитесь к библиотекарю на выдаче для получения услуги.",
    answerEn:
      "Yes, printing and copying services are available:\n• Black & white: 0.50 UAH/page\n• Color: 2.00 UAH/page\n• Copying: 0.50 UAH/copy\n\nAsk the librarian at the checkout desk for assistance.",
    category: "services",
    keywords: ["друк", "копія", "друкування", "printing", "copy"],
  },
];

/**
 * Search FAQ by keywords
 */
export function searchFAQ(
  query: string,
  language: "uk" | "ru" | "en" = "uk"
): FAQItem[] {
  const lowerQuery = query.toLowerCase();
  return libraryFAQ.filter((item) => {
    const questionField =
      language === "uk" ? item.questionUk : language === "ru" ? item.questionRu : item.questionEn;
    return (
      questionField.toLowerCase().includes(lowerQuery) ||
      item.keywords.some((k) => k.toLowerCase().includes(lowerQuery))
    );
  });
}

/**
 * Get FAQ by category
 */
export function getFAQByCategory(category: string): FAQItem[] {
  return libraryFAQ.filter((item) => item.category === category);
}

/**
 * Get all FAQ categories
 */
export function getFAQCategories(): string[] {
  return Array.from(new Set(libraryFAQ.map((item) => item.category)));
}

/**
 * Get random FAQ items for suggestions
 */
export function getRandomFAQ(count: number = 3): FAQItem[] {
  const shuffled = [...libraryFAQ].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
}
