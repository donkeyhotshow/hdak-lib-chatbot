/**
 * Mock Catalog Data Generator
 * Generates realistic test data for KSAC electronic catalog
 * Simulates documents from library catalog (303,552 total records)
 */

interface MockCatalogDocument {
  externalId: string;
  titleUk: string;
  authors: string[];
  year?: number;
  documentType?: string;
  language?: string;
  abstractUk?: string;
  keywords: string[];
  isbn?: string;
  issn?: string;
  publisher?: string;
  url: string;
  metadata: Record<string, unknown>;
}

export const mockCatalogDocuments: MockCatalogDocument[] = [
  {
    externalId: "catalog-001",
    titleUk: "Історія України: від найдавніших часів до сучасності",
    authors: ["Грушевський Михайло", "Костомаров Миколай"],
    year: 2021,
    documentType: "book",
    language: "uk",
    abstractUk:
      "Комплексна історія України, що охоплює всі періоди розвитку українського народу.",
    keywords: ["історія", "Україна", "культура", "суспільство"],
    isbn: "978-966-12-3456-7",
    publisher: "Видавництво ХДАК",
    url: "https://library-service.com.ua:8443/khkhdak/document/001",
    metadata: {
      catalogId: "001",
      source: "catalog",
    },
  },
  {
    externalId: "catalog-002",
    titleUk: "Українська мова: граматика та стилістика",
    authors: ["Селіванова Олена", "Ющук Ірина"],
    year: 2022,
    documentType: "book",
    language: "uk",
    abstractUk: "Повний курс української мови для студентів та викладачів.",
    keywords: ["мова", "граматика", "стилістика", "освіта"],
    isbn: "978-966-45-2345-6",
    publisher: "Видавництво ХДАК",
    url: "https://library-service.com.ua:8443/khkhdak/document/002",
    metadata: {
      catalogId: "002",
      source: "catalog",
    },
  },
  {
    externalId: "catalog-003",
    titleUk: "Мистецтво XX століття: авангард та модернізм",
    authors: ["Флоренський Павло", "Кандинський Василь"],
    year: 2020,
    documentType: "book",
    language: "uk",
    abstractUk:
      "Дослідження розвитку мистецтва XX століття з акцентом на авангард та модернізм.",
    keywords: ["мистецтво", "авангард", "модернізм", "XX століття"],
    isbn: "978-966-78-9012-3",
    publisher: "Видавництво ХДАК",
    url: "https://library-service.com.ua:8443/khkhdak/document/003",
    metadata: {
      catalogId: "003",
      source: "catalog",
    },
  },
  {
    externalId: "catalog-004",
    titleUk: "Філософія освіти: теорія та практика",
    authors: ["Корпанець Ігор", "Цимбалюк Вячеслав"],
    year: 2023,
    documentType: "book",
    language: "uk",
    abstractUk:
      "Філософський аналіз освітніх процесів та їх значення для розвитку суспільства.",
    keywords: ["філософія", "освіта", "теорія", "розвиток"],
    isbn: "978-966-11-3456-7",
    publisher: "Видавництво ХДАК",
    url: "https://library-service.com.ua:8443/khkhdak/document/004",
    metadata: {
      catalogId: "004",
      source: "catalog",
    },
  },
  {
    externalId: "catalog-005",
    titleUk: "Психологія особистості: розвиток та самореалізація",
    authors: ["Максименко Сергій", "Зінченко Володимир"],
    year: 2021,
    documentType: "book",
    language: "uk",
    abstractUk:
      "Дослідження психологічних механізмів розвитку особистості та її самореалізації.",
    keywords: ["психологія", "особистість", "розвиток", "самореалізація"],
    isbn: "978-966-54-7890-1",
    publisher: "Видавництво ХДАК",
    url: "https://library-service.com.ua:8443/khkhdak/document/005",
    metadata: {
      catalogId: "005",
      source: "catalog",
    },
  },
  {
    externalId: "catalog-006",
    titleUk: "Соціологія культури: методи та підходи",
    authors: ["Бойченко Максим", "Яковлєв Дмитро"],
    year: 2022,
    documentType: "article",
    language: "uk",
    abstractUk:
      "Статті про методологію соціологічного дослідження культури та культурних явищ.",
    keywords: ["соціологія", "культура", "методи", "дослідження"],
    issn: "2415-1234",
    publisher: "Журнал ХДАК",
    url: "https://library-service.com.ua:8443/khkhdak/document/006",
    metadata: {
      catalogId: "006",
      source: "catalog",
    },
  },
  {
    externalId: "catalog-007",
    titleUk: "Економіка культури: ринок та державна політика",
    authors: ["Гриценко Наталія", "Шевченко Дмитро"],
    year: 2023,
    documentType: "book",
    language: "uk",
    abstractUk:
      "Аналіз економічних аспектів культури та впливу державної політики на розвиток культурного сектору.",
    keywords: ["економіка", "культура", "ринок", "політика"],
    isbn: "978-966-89-1234-5",
    publisher: "Видавництво ХДАК",
    url: "https://library-service.com.ua:8443/khkhdak/document/007",
    metadata: {
      catalogId: "007",
      source: "catalog",
    },
  },
  {
    externalId: "catalog-008",
    titleUk: "Комунікація та медіа: сучасні тренди",
    authors: ["Іванова Світлана", "Петренко Іван"],
    year: 2024,
    documentType: "book",
    language: "uk",
    abstractUk:
      "Огляд сучасних трендів у комунікації та медіа, включаючи цифрові технології та соціальні мережі.",
    keywords: ["комунікація", "медіа", "тренди", "цифрові технології"],
    isbn: "978-966-99-5678-9",
    publisher: "Видавництво ХДАК",
    url: "https://library-service.com.ua:8443/khkhdak/document/008",
    metadata: {
      catalogId: "008",
      source: "catalog",
    },
  },
];

/**
 * Get all mock catalog documents
 */
export function getMockCatalogDocuments(): MockCatalogDocument[] {
  return mockCatalogDocuments;
}

/**
 * Search mock catalog documents by keyword
 */
export function searchMockCatalog(query: string): MockCatalogDocument[] {
  const lowerQuery = query.toLowerCase();
  return mockCatalogDocuments.filter((doc) => {
    return (
      doc.titleUk.toLowerCase().includes(lowerQuery) ||
      doc.abstractUk?.toLowerCase().includes(lowerQuery) ||
      doc.keywords.some((k) => k.toLowerCase().includes(lowerQuery)) ||
      doc.authors.some((a) => a.toLowerCase().includes(lowerQuery))
    );
  });
}

/**
 * Get mock catalog documents by year
 */
export function getMockCatalogDocumentsByYear(year: number): MockCatalogDocument[] {
  return mockCatalogDocuments.filter((doc) => doc.year === year);
}

/**
 * Get mock catalog documents by type
 */
export function getMockCatalogDocumentsByType(type: string): MockCatalogDocument[] {
  return mockCatalogDocuments.filter((doc) => doc.documentType === type);
}

/**
 * Get paginated mock catalog documents
 */
export function getMockCatalogDocumentsPaginated(
  page: number = 1,
  pageSize: number = 20
): { documents: MockCatalogDocument[]; total: number; page: number; pageSize: number } {
  const start = (page - 1) * pageSize;
  const end = start + pageSize;
  return {
    documents: mockCatalogDocuments.slice(start, end),
    total: mockCatalogDocuments.length,
    page,
    pageSize,
  };
}
