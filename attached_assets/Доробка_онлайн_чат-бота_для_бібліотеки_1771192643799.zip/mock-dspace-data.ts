/**
 * Mock DSpace Data Generator
 * Generates realistic test data for DSpace integration testing
 * Simulates documents from KSAC institutional repository
 */

import { ParsedDocument } from "./dspace-client";

export const mockDSpaceDocuments: ParsedDocument[] = [
  {
    externalId: "mock-uuid-001",
    titleUk: "Основи сучасної медицини: навчальний посібник",
    titleEn: "Fundamentals of Modern Medicine: Educational Guide",
    titleRu: "Основы современной медицины: учебное пособие",
    authors: [
      { name: "Петренко Іван Миколайович", email: "petrenko@hdak.edu.ua" },
      { name: "Сидоренко Марія Вікторівна" },
    ],
    year: 2023,
    documentType: "book",
    language: "uk",
    abstractUk:
      "Комплексний навчальний посібник, що охоплює основні концепції сучасної медицини, включаючи анатомію, фізіологію та патологію.",
    abstractEn:
      "Comprehensive educational guide covering fundamental concepts of modern medicine, including anatomy, physiology, and pathology.",
    keywords: ["медицина", "анатомія", "фізіологія", "навчання"],
    isbn: "978-966-12-3456-7",
    publisher: "Видавництво ХДАК",
    url: "https://repository.ac.kharkov.ua/items/mock-uuid-001",
    pdfUrl: "https://repository.ac.kharkov.ua/bitstreams/mock-001/download",
    metadata: {
      dspaceMetadata: [
        { key: "dc.title", value: "Основи сучасної медицини: навчальний посібник" },
        { key: "dc.creator", value: "Петренко Іван Миколайович" },
        { key: "dc.issued", value: "2023-01-15" },
      ],
    },
  },
  {
    externalId: "mock-uuid-002",
    titleUk: "Клінічна психологія: теорія та практика",
    titleEn: "Clinical Psychology: Theory and Practice",
    authors: [{ name: "Коваленко Ольга Сергіївна" }],
    year: 2022,
    documentType: "article",
    language: "uk",
    abstractUk:
      "Дослідження сучасних підходів до клінічної психології з практичними прикладами та методиками.",
    keywords: ["психологія", "клініка", "терапія", "дослідження"],
    issn: "2415-1234",
    publisher: "Журнал ХДАК",
    url: "https://repository.ac.kharkov.ua/items/mock-uuid-002",
    metadata: {},
  },
  {
    externalId: "mock-uuid-003",
    titleUk: "Інформаційні технології в охороні здоров'я",
    titleEn: "Information Technologies in Healthcare",
    authors: [
      { name: "Шевченко Дмитро Олегович" },
      { name: "Гриценко Наталія Іванівна" },
    ],
    year: 2024,
    documentType: "thesis",
    language: "uk",
    abstractUk:
      "Магістерська робота, присвячена застосуванню сучасних IT-технологій в системі охорони здоров'я України.",
    keywords: ["IT", "здоров'я", "технології", "системи"],
    url: "https://repository.ac.kharkov.ua/items/mock-uuid-003",
    metadata: {},
  },
  {
    externalId: "mock-uuid-004",
    titleUk: "Культура та мистецтво в контексті освіти",
    titleEn: "Culture and Art in Educational Context",
    authors: [{ name: "Литвин Василь Павлович" }],
    year: 2023,
    documentType: "book",
    language: "uk",
    abstractUk:
      "Монографія, що досліджує роль культури та мистецтва у формуванні освітнього простору.",
    keywords: ["культура", "мистецтво", "освіта", "розвиток"],
    isbn: "978-966-54-7890-1",
    publisher: "Видавництво ХДАК",
    url: "https://repository.ac.kharkov.ua/items/mock-uuid-004",
    pdfUrl: "https://repository.ac.kharkov.ua/bitstreams/mock-004/download",
    metadata: {},
  },
  {
    externalId: "mock-uuid-005",
    titleUk: "Методологія наукових досліджень у галузі культури",
    titleEn: "Research Methodology in Cultural Studies",
    authors: [
      { name: "Морозов Сергій Миколайович" },
      { name: "Іванова Світлана Вікторівна" },
    ],
    year: 2023,
    documentType: "book",
    language: "uk",
    abstractUk:
      "Навчальний посібник, що містить методологічні основи проведення наукових досліджень у галузі культури.",
    keywords: ["методологія", "дослідження", "культура", "наука"],
    isbn: "978-966-45-2345-6",
    publisher: "Видавництво ХДАК",
    url: "https://repository.ac.kharkov.ua/items/mock-uuid-005",
    metadata: {},
  },
  {
    externalId: "mock-uuid-006",
    titleUk: "Психологія творчості та інновацій",
    titleEn: "Psychology of Creativity and Innovation",
    authors: [{ name: "Бондаренко Анна Миколаївна" }],
    year: 2024,
    documentType: "article",
    language: "uk",
    abstractUk:
      "Стаття присвячена дослідженню психологічних механізмів творчості та інноваційного мислення.",
    keywords: ["психологія", "творчість", "інновації", "мислення"],
    issn: "2415-5678",
    publisher: "Журнал ХДАК",
    url: "https://repository.ac.kharkov.ua/items/mock-uuid-006",
    metadata: {},
  },
  {
    externalId: "mock-uuid-007",
    titleUk: "Соціальна робота та комунітарна розвиток",
    titleEn: "Social Work and Community Development",
    authors: [{ name: "Федоренко Олег Сергійович" }],
    year: 2023,
    documentType: "book",
    language: "uk",
    abstractUk:
      "Комплексний посібник з теорії та практики соціальної роботи в контексті комунітарного розвитку.",
    keywords: ["соціальна робота", "комунітар", "розвиток", "суспільство"],
    isbn: "978-966-78-9012-3",
    publisher: "Видавництво ХДАК",
    url: "https://repository.ac.kharkov.ua/items/mock-uuid-007",
    pdfUrl: "https://repository.ac.kharkov.ua/bitstreams/mock-007/download",
    metadata: {},
  },
  {
    externalId: "mock-uuid-008",
    titleUk: "Музична педагогіка: сучасні підходи",
    titleEn: "Music Pedagogy: Modern Approaches",
    authors: [
      { name: "Музиченко Ірина Вікторівна" },
      { name: "Гармонієнко Василь Петрович" },
    ],
    year: 2024,
    documentType: "book",
    language: "uk",
    abstractUk:
      "Навчальний посібник, що розглядає сучасні методи та підходи в музичній педагогіці.",
    keywords: ["музика", "педагогіка", "освіта", "методи"],
    isbn: "978-966-11-3456-7",
    publisher: "Видавництво ХДАК",
    url: "https://repository.ac.kharkov.ua/items/mock-uuid-008",
    metadata: {},
  },
];

/**
 * Get all mock documents
 */
export function getMockDocuments(): ParsedDocument[] {
  return mockDSpaceDocuments;
}

/**
 * Get mock documents by keyword
 */
export function searchMockDocuments(query: string): ParsedDocument[] {
  const lowerQuery = query.toLowerCase();
  return mockDSpaceDocuments.filter((doc) => {
    return (
      doc.titleUk.toLowerCase().includes(lowerQuery) ||
      doc.titleEn?.toLowerCase().includes(lowerQuery) ||
      doc.abstractUk?.toLowerCase().includes(lowerQuery) ||
      doc.keywords.some((k) => k.toLowerCase().includes(lowerQuery))
    );
  });
}

/**
 * Get mock documents by year
 */
export function getMockDocumentsByYear(year: number): ParsedDocument[] {
  return mockDSpaceDocuments.filter((doc) => doc.year === year);
}

/**
 * Get mock documents by type
 */
export function getMockDocumentsByType(type: string): ParsedDocument[] {
  return mockDSpaceDocuments.filter((doc) => doc.documentType === type);
}
