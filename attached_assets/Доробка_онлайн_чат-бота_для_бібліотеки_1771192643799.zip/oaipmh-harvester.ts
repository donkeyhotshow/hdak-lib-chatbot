/**
 * OAI-PMH Harvester
 * Harvests metadata from KSAC DSpace repository using OAI-PMH protocol
 * Supports incremental harvesting with resumption tokens
 */

import axios, { AxiosInstance } from "axios";
import { parseStringPromise } from "xml2js";

const OAI_PMH_BASE_URL = "https://repository.ac.kharkov.ua/oai/request";

interface OAIRecord {
  header: {
    identifier: string[];
    datestamp: string[];
    setSpec?: string[];
    status?: string[];
  };
  metadata?: {
    "oai_dc:dc": Record<string, string[]>;
  };
}

interface OAIResponse {
  "OAI-PMH": {
    ListRecords?: {
      record?: OAIRecord[];
      resumptionToken?: string[];
    };
    ListIdentifiers?: {
      header?: Array<OAIRecord["header"]>;
      resumptionToken?: string[];
    };
    error?: {
      _: string;
      $: { code: string };
    }[];
  };
}

export interface HarvestedDocument {
  externalId: string;
  titleUk: string;
  titleEn?: string;
  authors: string[];
  year?: number;
  documentType?: string;
  language?: string;
  abstractUk?: string;
  keywords: string[];
  url: string;
  datestamp: string;
}

class OAIPMHHarvester {
  private client: AxiosInstance;

  constructor() {
    this.client = axios.create({
      baseURL: OAI_PMH_BASE_URL,
      timeout: 30000,
    });
  }

  /**
   * List all records from OAI-PMH endpoint
   */
  async listRecords(
    metadataPrefix: string = "oai_dc",
    from?: string,
    until?: string,
    resumptionToken?: string
  ): Promise<{
    records: OAIRecord[];
    resumptionToken?: string;
  }> {
    try {
      const params: Record<string, string> = {
        verb: "ListRecords",
        metadataPrefix,
      };

      if (resumptionToken) {
        params.resumptionToken = resumptionToken;
      } else {
        if (from) params.from = from;
        if (until) params.until = until;
      }

      const response = await this.client.get("", { params });
      const parsed = (await parseStringPromise(response.data)) as OAIResponse;

      const records = parsed["OAI-PMH"].ListRecords?.record || [];
      const nextToken = parsed["OAI-PMH"].ListRecords?.resumptionToken?.[0];

      return {
        records,
        resumptionToken: nextToken,
      };
    } catch (error) {
      console.error("[OAI-PMH] ListRecords error:", error);
      throw error;
    }
  }

  /**
   * List all identifiers (headers only)
   */
  async listIdentifiers(
    metadataPrefix: string = "oai_dc",
    from?: string,
    until?: string,
    resumptionToken?: string
  ): Promise<{
    headers: OAIRecord["header"][];
    resumptionToken?: string;
  }> {
    try {
      const params: Record<string, string> = {
        verb: "ListIdentifiers",
        metadataPrefix,
      };

      if (resumptionToken) {
        params.resumptionToken = resumptionToken;
      } else {
        if (from) params.from = from;
        if (until) params.until = until;
      }

      const response = await this.client.get("", { params });
      const parsed = (await parseStringPromise(response.data)) as OAIResponse;

      const headers = parsed["OAI-PMH"].ListIdentifiers?.header || [];
      const nextToken =
        parsed["OAI-PMH"].ListIdentifiers?.resumptionToken?.[0];

      return {
        headers,
        resumptionToken: nextToken,
      };
    } catch (error) {
      console.error("[OAI-PMH] ListIdentifiers error:", error);
      throw error;
    }
  }

  /**
   * Get a single record by identifier
   */
  async getRecord(
    identifier: string,
    metadataPrefix: string = "oai_dc"
  ): Promise<OAIRecord> {
    try {
      const response = await this.client.get("", {
        params: {
          verb: "GetRecord",
          identifier,
          metadataPrefix,
        },
      });

      const parsed = (await parseStringPromise(response.data)) as OAIResponse;
      const record = parsed["OAI-PMH"].ListRecords?.record?.[0];

      if (!record) {
        throw new Error(`Record not found: ${identifier}`);
      }

      return record;
    } catch (error) {
      console.error(`[OAI-PMH] GetRecord error for ${identifier}:`, error);
      throw error;
    }
  }

  /**
   * Parse OAI-PMH Dublin Core metadata to internal format
   */
  parseRecord(record: OAIRecord): HarvestedDocument {
    const metadata = record.metadata?.["oai_dc:dc"] || {};
    const identifier = record.header.identifier[0];
    const datestamp = record.header.datestamp[0];

    // Extract title (prefer first title)
    const titleUk = metadata["dc:title"]?.[0] || "Unknown";

    // Extract authors
    const authors = metadata["dc:creator"] || [];

    // Extract year from date
    const dateStr = metadata["dcterms:issued"]?.[0] || metadata["dc:date"]?.[0];
    const year = dateStr ? parseInt(dateStr.split("-")[0]) : undefined;

    // Extract document type
    const documentType = metadata["dc:type"]?.[0];

    // Extract language
    const language = metadata["dc:language"]?.[0];

    // Extract abstract
    const abstractUk = metadata["dcterms:abstract"]?.[0];

    // Extract keywords/subjects
    const keywords = metadata["dc:subject"] || [];

    // Build URL
    const url = `https://repository.ac.kharkov.ua/items/${identifier.replace("oai:repository.ac.kharkov.ua:", "")}`;

    return {
      externalId: identifier,
      titleUk,
      authors,
      year,
      documentType,
      language,
      abstractUk,
      keywords,
      url,
      datestamp,
    };
  }

  /**
   * Harvest all records with resumption token support
   */
  async harvestAll(
    from?: string,
    until?: string,
    maxRecords?: number
  ): Promise<HarvestedDocument[]> {
    const documents: HarvestedDocument[] = [];
    let resumptionToken: string | undefined;
    let recordCount = 0;

    try {
      do {
        console.log(
          `[OAI-PMH] Harvesting records (offset: ${recordCount})...`
        );

        const result = await this.listRecords(
          "oai_dc",
          resumptionToken ? undefined : from,
          resumptionToken ? undefined : until,
          resumptionToken
        );

        for (const record of result.records) {
          if (maxRecords && recordCount >= maxRecords) {
            break;
          }

          try {
            const parsed = this.parseRecord(record);
            documents.push(parsed);
            recordCount++;
          } catch (error) {
            console.error("[OAI-PMH] Failed to parse record:", error);
          }
        }

        resumptionToken = result.resumptionToken;

        if (maxRecords && recordCount >= maxRecords) {
          break;
        }
      } while (resumptionToken);

      console.log(`[OAI-PMH] Harvesting completed. Total records: ${recordCount}`);
    } catch (error) {
      console.error("[OAI-PMH] Harvesting error:", error);
    }

    return documents;
  }

  /**
   * Harvest incremental updates since last sync
   */
  async harvestSince(lastSyncTime: Date): Promise<HarvestedDocument[]> {
    const from = lastSyncTime.toISOString().split("T")[0];
    return this.harvestAll(from);
  }
}

export const oaipmhHarvester = new OAIPMHHarvester();
