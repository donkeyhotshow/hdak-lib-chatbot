import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { generateText } from "ai";
import { openai } from "@ai-sdk/openai";
import * as db from "./db";

// Admin-only procedure
const adminProcedure = protectedProcedure.use(async ({ ctx, next }) => {
  if (ctx.user?.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  }
  return next({ ctx });
});

// System prompt for the AI chatbot
const getSystemPrompt = (language: string) => {
  const prompts: Record<string, string> = {
    en: `You are a helpful AI assistant for the KSAC (King Saud bin Abdulaziz University for Health Sciences) library. 
Your role is to help users discover and access library resources through conversational interaction.

Key responsibilities:
1. Help users find library resources by answering questions about available materials
2. Provide information about electronic libraries, repositories, catalogs, and databases
3. Guide users on how to access different types of resources
4. Answer questions about library services and functionality
5. Suggest relevant resources based on user queries
6. For complex research needs, direct users to submit a thematic search request via Google Form

When responding:
- Be helpful, friendly, and professional
- Provide direct links to resources when available
- If a resource is not found in the database, acknowledge this and suggest alternatives
- Keep responses concise and focused on the user's query
- Ask clarifying questions if needed to better assist the user`,
    
    uk: `Ви - корисний AI-помічник бібліотеки KSAC (Університету медичних наук імені короля Сауда бін Абдулазіза).
Ваша роль - допомогти користувачам знайти та отримати доступ до ресурсів бібліотеки через розмовну взаємодію.

Основні обов'язки:
1. Допомогти користувачам знайти ресурси бібліотеки, відповідаючи на запитання про доступні матеріали
2. Надати інформацію про електронні бібліотеки, репозиторії, каталоги та бази даних
3. Керувати користувачами щодо того, як отримати доступ до різних типів ресурсів
4. Відповідати на запитання про послуги та функціональність бібліотеки
5. Пропонувати відповідні ресурси на основі запитів користувача
6. Для складних дослідницьких потреб спрямовувати користувачів на подання запиту на тематичний пошук через Google Form
