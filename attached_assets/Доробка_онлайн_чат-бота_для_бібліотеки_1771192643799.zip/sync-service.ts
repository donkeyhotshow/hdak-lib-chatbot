/**
 * Synchronization Service
 * Manages periodic synchronization of documents from DSpace and catalog
 */

import { dspaceClient } from "./dspace-client";
import { oaipmhHarvester } from "./oaipmh-harvester";
import {
  upsertDocument,
  updateDspaceSyncStatus,
  updateCatalogSyncStatus,
  getDspaceSyncStatus,
  getCatalogSyncStatus,
} from "./db-documents";
import type { InsertDocument } from "../drizzle/schema";

class SyncService {
  private dspaceSyncInterval: NodeJS.Timeout | null = null;
  private catalogSyncInterval: NodeJS.Timeout | null = null;

  /**
   * Sync documents from DSpace repository
   */
  async syncDSpace(maxDocuments?: number): Promise<{
    success: boolean;
    totalDocuments: number;
    newDocuments: number;
    updatedDocuments: number;
    error?: string;
  }> {
    try {
      console.log("[SyncService] Starting DSpace synchronization...");

      await updateDspaceSyncStatus({
        syncStatus: "syncing",
      });

      // Harvest documents from DSpace
      const harvestedDocs = await dspaceClient.harvestAll(maxDocuments);
      console.log(
        `[SyncService] Harvested ${harvestedDocs.length} documents from DSpace`
      );

      let newCount = 0;
      let updatedCount = 0;

      // Store documents in database
      for (const doc of harvestedDocs) {
        const insertDoc: InsertDocument = {
          source: "dspace",
          externalId: doc.externalId,
          titleUk: doc.titleUk,
          titleEn: doc.titleEn,
          titleRu: doc.titleRu,
          authors: JSON.stringify(doc.authors),
          year: doc.year,
          documentType: doc.documentType,
          language: doc.language,
          abstractUk: doc.abstractUk,
          abstractEn: doc.abstractEn,
          abstractRu: doc.abstractRu,
          keywords: JSON.stringify(doc.keywords),
          isbn: doc.isbn,
          issn: doc.issn,
          publisher: doc.publisher,
          url: doc.url,
          pdfUrl: doc.pdfUrl,
          metadata: JSON.stringify(doc.metadata),
          lastSyncedAt: new Date(),
        };

        const result = await upsertDocument(insertDoc);
        if (result) {
          if (result.createdAt === result.updatedAt) {
            newCount++;
          } else {
            updatedCount++;
          }
        }
      }

      // Update sync status
      await updateDspaceSyncStatus({
        syncStatus: "completed",
        lastSyncTime: new Date(),
        totalDocuments: harvestedDocs.length,
        newDocuments: newCount,
        updatedDocuments: updatedCount,
        errorMessage: null,
      });

      console.log(
        `[SyncService] DSpace sync completed: ${newCount} new, ${updatedCount} updated`
      );

      return {
        success: true,
        totalDocuments: harvestedDocs.length,
        newDocuments: newCount,
        updatedDocuments: updatedCount,
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      console.error("[SyncService] DSpace sync error:", error);

      await updateDspaceSyncStatus({
        syncStatus: "failed",
        errorMessage,
      });

      return {
        success: false,
        totalDocuments: 0,
        newDocuments: 0,
        updatedDocuments: 0,
        error: errorMessage,
      };
    }
  }

  /**
   * Sync documents from OAI-PMH (incremental)
   */
  async syncOAIPMH(lastSyncTime?: Date): Promise<{
    success: boolean;
    totalDocuments: number;
    newDocuments: number;
    updatedDocuments: number;
    error?: string;
  }> {
    try {
      console.log("[SyncService] Starting OAI-PMH incremental sync...");

      const from = lastSyncTime
        ? lastSyncTime.toISOString().split("T")[0]
        : undefined;

      // Harvest documents using OAI-PMH
      const harvestedDocs = await oaipmhHarvester.harvestAll(from);
      console.log(
        `[SyncService] Harvested ${harvestedDocs.length} documents via OAI-PMH`
      );

      let newCount = 0;
      let updatedCount = 0;

      // Store documents in database
      for (const doc of harvestedDocs) {
        const insertDoc: InsertDocument = {
          source: "dspace",
          externalId: doc.externalId,
          titleUk: doc.titleUk,
          titleEn: doc.titleEn,
          authors: JSON.stringify(doc.authors),
          year: doc.year,
          documentType: doc.documentType,
          language: doc.language,
          abstractUk: doc.abstractUk,
          keywords: JSON.stringify(doc.keywords),
          url: doc.url,
          metadata: JSON.stringify({ datestamp: doc.datestamp }),
          lastSyncedAt: new Date(),
        };

        const result = await upsertDocument(insertDoc);
        if (result) {
          if (result.createdAt === result.updatedAt) {
            newCount++;
          } else {
            updatedCount++;
          }
        }
      }

      console.log(
        `[SyncService] OAI-PMH sync completed: ${newCount} new, ${updatedCount} updated`
      );

      return {
        success: true,
        totalDocuments: harvestedDocs.length,
        newDocuments: newCount,
        updatedDocuments: updatedCount,
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      console.error("[SyncService] OAI-PMH sync error:", error);

      return {
        success: false,
        totalDocuments: 0,
        newDocuments: 0,
        updatedDocuments: 0,
        error: errorMessage,
      };
    }
  }

  /**
   * Start periodic DSpace synchronization
   */
  startDSpaceSync(intervalMs: number = 24 * 60 * 60 * 1000): void {
    if (this.dspaceSyncInterval) {
      clearInterval(this.dspaceSyncInterval);
    }

    console.log(
      `[SyncService] Starting DSpace sync scheduler (interval: ${intervalMs}ms)`
    );

    // Run sync immediately
    this.syncDSpace();

    // Schedule periodic syncs
    this.dspaceSyncInterval = setInterval(() => {
      this.syncDSpace();
    }, intervalMs);
  }

  /**
   * Start periodic OAI-PMH synchronization
   */
  startOAIPMHSync(intervalMs: number = 6 * 60 * 60 * 1000): void {
    if (this.catalogSyncInterval) {
      clearInterval(this.catalogSyncInterval);
    }

    console.log(
      `[SyncService] Starting OAI-PMH sync scheduler (interval: ${intervalMs}ms)`
    );

    // Run sync immediately
    this.syncOAIPMH();

    // Schedule periodic syncs
    this.catalogSyncInterval = setInterval(async () => {
      const status = await getDspaceSyncStatus();
      if (status?.lastSyncTime) {
        this.syncOAIPMH(status.lastSyncTime);
      } else {
        this.syncOAIPMH();
      }
    }, intervalMs);
  }

  /**
   * Stop all synchronization
   */
  stopSync(): void {
    if (this.dspaceSyncInterval) {
      clearInterval(this.dspaceSyncInterval);
      this.dspaceSyncInterval = null;
    }

    if (this.catalogSyncInterval) {
      clearInterval(this.catalogSyncInterval);
      this.catalogSyncInterval = null;
    }

    console.log("[SyncService] Synchronization stopped");
  }

  /**
   * Get sync status
   */
  async getSyncStatus(): Promise<{
    dspace: any;
    catalog: any;
  }> {
    const dspaceStatus = await getDspaceSyncStatus();
    const catalogStatus = await getCatalogSyncStatus();

    return {
      dspace: dspaceStatus,
      catalog: catalogStatus,
    };
  }
}

export const syncService = new SyncService();
