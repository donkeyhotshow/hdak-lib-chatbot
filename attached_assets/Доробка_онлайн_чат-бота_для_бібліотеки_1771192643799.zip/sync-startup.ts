/**
 * Startup Synchronization
 * Syncs mock data into database on application startup
 */

import { enhancedSyncService } from "./sync-service-enhanced";

let syncInitialized = false;

/**
 * Initialize synchronization on startup
 * This runs once when the server starts
 */
export async function initializeSyncOnStartup(): Promise<void> {
  if (syncInitialized) {
    console.log("[Sync] Already initialized, skipping...");
    return;
  }

  try {
    console.log("[Sync] Initializing startup synchronization...");

    // Sync DSpace with mock data
    console.log("[Sync] Syncing DSpace repository...");
    const dspaceResult = await enhancedSyncService.syncDSpace();
    console.log(`[Sync] DSpace: ${dspaceResult.totalDocuments} documents (${dspaceResult.newDocuments} new)`);

    // Sync Catalog with mock data
    console.log("[Sync] Syncing electronic catalog...");
    const catalogResult = await enhancedSyncService.syncCatalog();
    console.log(`[Sync] Catalog: ${catalogResult.totalDocuments} documents (${catalogResult.newDocuments} new)`);

    // Start periodic synchronization (optional)
    // Sync every 24 hours for DSpace, every 6 hours for catalog
    // enhancedSyncService.startPeriodicSync(24 * 60 * 60 * 1000, 6 * 60 * 60 * 1000);

    console.log("[Sync] Startup synchronization complete!");
    syncInitialized = true;
  } catch (error) {
    console.error("[Sync] Startup synchronization error:", error);
    // Don't throw - allow server to continue even if sync fails
  }
}

/**
 * Check if sync is initialized
 */
export function isSyncInitialized(): boolean {
  return syncInitialized;
}
