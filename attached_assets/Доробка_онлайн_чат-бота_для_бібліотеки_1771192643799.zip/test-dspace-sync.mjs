#!/usr/bin/env node

/**
 * DSpace Synchronization Test Script
 * Tests DSpace REST API and OAI-PMH integration
 * Harvests sample documents and verifies metadata quality
 */

import axios from "axios";
import { parseStringPromise } from "xml2js";

const DSPACE_BASE_URL = "https://repository.ac.kharkov.ua/api";
const OAI_PMH_URL = "https://repository.ac.kharkov.ua/oai/request";

async function testDSpaceSearch() {
  console.log("\n📡 Testing DSpace REST API Search...\n");

  try {
    const response = await axios.get(
      `${DSPACE_BASE_URL}/discover/search/objects`,
      {
        params: {
          query: "*",
          dsoType: "item",
          page: 0,
          size: 5,
          configuration: "default",
        },
        timeout: 15000,
      }
    );

    const payload = response.data.payload;
    console.log(`✅ DSpace API Response:`);
    console.log(`   Total Elements: ${payload.totalElements}`);
    console.log(`   Current Page: ${payload.currentPage}`);
    console.log(`   Page Size: ${payload.pageSize}`);
    console.log(`   Total Pages: ${payload.totalPages}`);

    if (payload._embedded?.searchResultObjects?.length > 0) {
      console.log(`\n📚 Sample Documents (${payload._embedded.searchResultObjects.length}):`);

      payload._embedded.searchResultObjects.forEach((result, index) => {
        const item = result._embedded?.indexableObject;
        if (item) {
          const title = item.metadata?.find((m) => m.key === "dc.title")?.value || "Unknown";
          const author = item.metadata?.find((m) => m.key === "dc.creator")?.value || "Unknown";
          console.log(`\n   ${index + 1}. "${title}"`);
          console.log(`      Author: ${author}`);
          console.log(`      UUID: ${item.uuid}`);
        }
      });

      return true;
    } else {
      console.log("⚠️  No documents found in DSpace");
      return false;
    }
  } catch (error) {
    console.error("❌ DSpace API Error:", error.message);
    if (error.response?.status === 404) {
      console.error("   Repository may not be accessible or API endpoint changed");
    }
    return false;
  }
}

async function testOAIPMH() {
  console.log("\n📡 Testing OAI-PMH Harvesting...\n");

  try {
    const response = await axios.get(OAI_PMH_URL, {
      params: {
        verb: "ListRecords",
        metadataPrefix: "oai_dc",
        page: 0,
        size: 5,
      },
      timeout: 15000,
    });

    const parsed = await parseStringPromise(response.data);
    const records = parsed["OAI-PMH"]?.ListRecords?.record || [];

    console.log(`✅ OAI-PMH Response:`);
    console.log(`   Records Retrieved: ${records.length}`);

    if (records.length > 0) {
      console.log(`\n📚 Sample Records:`);

      records.slice(0, 3).forEach((record, index) => {
        const metadata = record.metadata?.[0]?.["oai_dc:dc"]?.[0] || {};
        const title = metadata["dc:title"]?.[0] || "Unknown";
        const creator = metadata["dc:creator"]?.[0] || "Unknown";
        const identifier = record.header?.[0]?.identifier?.[0] || "Unknown";

        console.log(`\n   ${index + 1}. "${title}"`);
        console.log(`      Creator: ${creator}`);
        console.log(`      Identifier: ${identifier}`);
      });

      return true;
    } else {
      console.log("⚠️  No records found via OAI-PMH");
      return false;
    }
  } catch (error) {
    console.error("❌ OAI-PMH Error:", error.message);
    if (error.response?.status === 404) {
      console.error("   OAI-PMH endpoint may not be accessible");
    }
    return false;
  }
}

async function testDSpaceItem() {
  console.log("\n📡 Testing DSpace Item Retrieval...\n");

  try {
    // First, get a sample item UUID
    const searchResponse = await axios.get(
      `${DSPACE_BASE_URL}/discover/search/objects`,
      {
        params: {
          query: "*",
          dsoType: "item",
          page: 0,
          size: 1,
        },
        timeout: 15000,
      }
    );

    const item = searchResponse.data.payload._embedded?.searchResultObjects?.[0]?._embedded?.indexableObject;

    if (!item) {
      console.log("⚠️  No items available for detailed retrieval test");
      return false;
    }

    const uuid = item.uuid;
    console.log(`Testing item retrieval for UUID: ${uuid}\n`);

    const itemResponse = await axios.get(`${DSPACE_BASE_URL}/core/items/${uuid}`, {
      timeout: 15000,
    });

    const fullItem = itemResponse.data;
    console.log(`✅ Item Retrieved Successfully:`);
    console.log(`   UUID: ${fullItem.uuid}`);
    console.log(`   Name: ${fullItem.name}`);
    console.log(`   Metadata Fields: ${fullItem.metadata?.length || 0}`);

    if (fullItem.bitstreams?.length > 0) {
      console.log(`   Bitstreams: ${fullItem.bitstreams.length}`);
      fullItem.bitstreams.slice(0, 2).forEach((bs, idx) => {
        console.log(`      ${idx + 1}. ${bs.name} (${bs.mimeType})`);
      });
    }

    return true;
  } catch (error) {
    console.error("❌ Item Retrieval Error:", error.message);
    return false;
  }
}

async function main() {
  console.log("🔍 KSAC DSpace & OAI-PMH Integration Test\n");
  console.log("=" .repeat(50));

  const results = {
    dspaceSearch: await testDSpaceSearch(),
    oaipmh: await testOAIPMH(),
    dspaceItem: await testDSpaceItem(),
  };

  console.log("\n" + "=".repeat(50));
  console.log("\n📊 Test Summary:");
  console.log(`   DSpace Search: ${results.dspaceSearch ? "✅ PASS" : "❌ FAIL"}`);
  console.log(`   OAI-PMH: ${results.oaipmh ? "✅ PASS" : "❌ FAIL"}`);
  console.log(`   DSpace Item Retrieval: ${results.dspaceItem ? "✅ PASS" : "❌ FAIL"}`);

  const passCount = Object.values(results).filter(Boolean).length;
  console.log(`\n   Overall: ${passCount}/3 tests passed\n`);

  if (passCount === 3) {
    console.log("✅ All tests passed! DSpace integration is ready for synchronization.\n");
    process.exit(0);
  } else {
    console.log("⚠️  Some tests failed. Check the errors above.\n");
    process.exit(1);
  }
}

main().catch((error) => {
  console.error("Fatal error:", error);
  process.exit(1);
});
