# KSAC Library Chatbot - Project TODO

## Core Infrastructure
- [x] Fix AI SDK import errors in server/routers.ts
- [x] Create complete database schema with all tables (users, conversations, messages, libraryResources, libraryContacts, libraryInfo, userQueries)
- [x] Run database migrations (pnpm db:push)
- [x] Create seed script for initial library resources and contacts

## Backend API (tRPC Procedures)
- [x] Implement conversation management procedures (createConversation, getConversations, getMessages)
- [x] Implement sendMessage procedure with AI response generation
- [x] Implement resource management procedures (getAll, search, add, update, delete)
- [x] Implement contact management procedures (getAll, add)
- [x] Implement library info procedures (get, set)
- [x] Implement analytics logging to userQueries table
- [x] Add proper error handling and validation

## Frontend - Chat Interface
- [x] Build bilingual chat component with conversation history
- [x] Implement language switcher (Ukrainian/Russian)
- [x] Add streaming AI response support
- [x] Display resource suggestions in chat
- [x] Add conversation creation and history navigation
- [x] Implement message input with send button

## Frontend - Admin Panel
- [x] Create admin authentication check
- [x] Build resource management interface (add, edit, delete)
- [x] Build contact management interface (add, edit, delete)
- [x] Add library info editor
- [x] Implement admin access control (role-based)

## AI & Search Functionality
- [x] Create enhanced system prompts with KSAC-specific context
- [x] Implement resource search by keywords
- [x] Add resource filtering by type
- [x] Integrate Google Form link for thematic search
- [x] Configure AI to provide relevant resource links

## Testing & Optimization
- [x] Test bilingual chat functionality
- [x] Test conversation history persistence
- [x] Test admin panel access control
- [x] Test resource search and filtering
- [x] Verify analytics logging
- [x] Check for console errors and server logs
- [x] Optimize database queries

## Deployment
- [ ] Create checkpoint
- [ ] Verify dev server stability
- [ ] Prepare deployment documentation

## DSpace Repository Integration (Phase 1)
- [ ] Create DSpace API client (REST API integration)
- [ ] Implement search functionality (query, pagination, filtering)
- [ ] Parse Dublin Core metadata from DSpace responses
- [ ] Extract PDF/document links from DSpace items
- [ ] Create tRPC procedures for repository search
- [ ] Handle authentication and error cases
- [ ] Test DSpace API connectivity and data retrieval

## OAI-PMH Harvesting (Phase 2)
- [ ] Create OAI-PMH client library
- [ ] Implement metadata harvesting (ListRecords, GetRecord)
- [ ] Parse Dublin Core and MARC21 formats
- [ ] Create synchronization scheduler (daily/weekly)
- [ ] Store harvested metadata in database
- [ ] Handle incremental updates and deletions
- [ ] Create admin interface for sync status

## Electronic Catalog Integration (Phase 3)
- [ ] Analyze catalog structure and search form
- [ ] Implement web scraping solution (if needed)
- [ ] Parse catalog search results
- [ ] Extract document metadata and links
- [ ] Create tRPC procedures for catalog search
- [ ] Integrate with main search interface
- [ ] Test catalog data accuracy

## Database Schema Updates (Phase 4)
- [ ] Add documents table for storing real library documents
- [ ] Add metadata fields (authors, year, language, keywords)
- [ ] Create indexes for full-text search
- [ ] Add source tracking (DSpace, Catalog, etc.)
- [ ] Update relationships between tables
- [ ] Run migrations

## AI Prompts & UI Updates (Phase 5)
- [ ] Update system prompts with real KSAC resources (Ukrainian)
- [ ] Add resource type icons and badges
- [ ] Create document detail view
- [ ] Add filters for document type, year, language
- [ ] Display author and publication information
- [ ] Add direct links to documents
- [ ] Implement Ukrainian language throughout

## Testing & Verification (Phase 6)
- [ ] Test DSpace API integration
- [ ] Verify OAI-PMH harvesting
- [ ] Check data accuracy and completeness
- [ ] Test search functionality across all sources
- [ ] Verify Ukrainian language content
- [ ] Performance testing with large datasets
- [ ] Error handling and edge cases
